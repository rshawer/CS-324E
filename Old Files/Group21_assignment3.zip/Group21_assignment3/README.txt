Assignment 3	


extrac_words.py -
	
Creates: allwords.txt, uniquewords.txt, and wordfrequency.txt

In order to create these text files, the chosen book's .txt file must be added to the script's code body. Then, the script must be run through terminal or a comparable apparatus. Upon running the .txt files are generated and can be used in the following processing files.
The three text files will be created in the folder. Put the uniquewords.txt in the a3_novelvisualization folder. Put the wordfrequency file in the a3_wordfrequency file.

a3_novelvisualization

In order to run this program, the file path to the uniquewords.txt file must be included in the processing code body. This can be simplified by simply placing a copy of the uniquewords.txt file within the processing file folder to access the text document
using a local directory. Hitting play on the processing UI generates the word cloud. Upon pressing the left mouse button, a new word 
cloud is generated. 


a3_wordfrequency

The steps to run this file are the same as the a3_novelvisualization file, except this uses the wordfrequency.txt instead of the uniquewords.txt file.


Sherlock_wordle.png

Steps to produce a simliar file can be found on the wordle home page. This must be done through either the in browser UI or 
desktop application.
